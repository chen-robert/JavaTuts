
/**
 * The purpose of this program is to create a template of a phishing scam letter.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class PhisingScam
{
    public static void main(String[] args)
    {
        String line0 = "<financial institution>";
        
        String line1 = "To: <recipient full name>";
        
        String line2 = "From: <sender full name>";        
        
        String line3 = "Date: <today's date>";

        String line4 = "Dear <title> <last name>,";

        String line5 = "On <month day> we noticed a suspicious withdrawal of <amount> \nfrom your checking account.";

        String line6 = "If this information is not correct, someone \nunknown to you may have access to your account!";
        
        String line7 = "For your safety, please visit <web site> to \nverify your personal information.";
        
        String line8 = "<recipient first name>, once you have done this, our fraud \ndepartment will work to resolve this discrepancy.";  
        
        String line9 = "Thank you,";
        
        String line10 = "<sender first and last name>";

        

        System.out.println(line0);
        System.out.println();
        System.out.println(line1);
        System.out.println(line2);
        System.out.println(line3);
        System.out.println();
        System.out.println(line4);
        System.out.println();
        System.out.println(line5);
        System.out.println();
        System.out.println(line6);
        System.out.println();
        System.out.println(line7);
        System.out.println();
        System.out.println(line8);
        System.out.println();
        System.out.println(line9);
        System.out.println(line10);

       
       
    }
}
